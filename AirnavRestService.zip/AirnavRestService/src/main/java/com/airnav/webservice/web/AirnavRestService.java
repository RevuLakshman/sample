package com.airnav.webservice.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api/airnav")
public class AirnavRestService {
	
	private static final Logger LOG = LoggerFactory.getLogger(AirnavRestService.class);

	@RequestMapping(path = "/hello", produces = "application/json" )
	public ResponseEntity<String> sayHello(@RequestParam(value = "reportType") String reportType, 
										   @RequestParam(value = "datasheetType") String datasheetType){
		LOG.info("This is AirnavRestService >>>>>>> sayHello() >>>>>>>>> reportType : {}",reportType);
		ResponseEntity<String> response = process(reportType);
		//response need to encode here using Base64
		return ResponseEntity.ok(response.getBody());
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private ResponseEntity<String> process(String message){
		
		String url =  "http://localhost:8080/api/test/hello/"+message;
		RestTemplate temp = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		//headers.set("token", null);
		HttpEntity entity = new HttpEntity(headers);
		return temp.exchange(url, HttpMethod.POST, entity, String.class);
	} 
}
