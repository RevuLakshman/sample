package com.airnav.webservice.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/test")
public class TestRestService {
	
	private static final Logger LOG = LoggerFactory.getLogger(TestRestService.class);
	@RequestMapping(value = "/hello/{message}")
	public ResponseEntity<String> sayHello(@PathVariable("message") String msg){
		LOG.info("This is TestRestService >>>>>>> sayHello() >>>>>>>>>>> Message : {}",msg);
		String modified = msg + "@@@@@@@@@ Added";
		return ResponseEntity.ok(modified);
	}
}
