package com.airnav.webservice.web.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class AirnavRestServiceImpl {

	private static final Logger LOG = LoggerFactory.getLogger(AirnavRestServiceImpl.class);
	
	
	
	//RestTemplate restTemplate = new RestTemplate();
	
	RestTemplate restTemplate = new RestTemplate();

	
	String url =  "http://localhost:8080/api/test/hello/This is test message";
	
	//HttpHeaders headers = new HttpHeaders();
	
	//headers.set("token", null);

	//HttpEntity entity = new HttpEntity(headers);
	
	//restTemplate.
	
	//ResponseEntity<List<Asset>> response = restTemplate.exchange(url, HttpMethod.GET, entity, 
	//		new ParameterizedTypeReference<List<Asset>>(){} );
}
